#ifndef DDZDIALOG_H
#define DDZDIALOG_H

#include "base/BaseDialog.h"

namespace Ui {
class DDZDialog;
}

class DDZDialog : public BaseDialog
{
    Q_OBJECT

public:
    explicit DDZDialog(QWidget *parent = 0);
    ~DDZDialog();

    void setProductDir(QString dir);

    void updateProductDir();

protected:
    void copyBgToResource(QString path);

    void copyBgToStudio(QString path);

private slots:
    void on_startBtn_clicked();

    void on_targetBtn_clicked();

    void on_bg_resource_clicked();

    void on_bg_studio_clicked();

private:
    Ui::DDZDialog *ui;

};

#endif // DDZDIALOG_H
