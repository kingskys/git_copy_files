#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Manager.h"
#include "ddz/DDZDialog.h"
#include "config/ConfigDialog.h"
#include "appicon/IconDialog.h"
#include "logo/LogoDialog.h"
#include "hall/HallDialog.h"
#include "brnn/BRNNDialog.h"
#include "zjh/ZJHDialog.h"
#include "bjl/BJLDialog.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_view_ddz_clicked();

    void on_view_config_clicked();

    void on_view_logo_clicked();

    void on_view_icon_clicked();

    void on_view_hall_clicked();

    void on_view_tool_clicked();

    void on_view_brnn_clicked();

    void on_record_clicked();

    void on_view_zjh_clicked();

    void on_view_bjl_clicked();

private:
    Ui::MainWindow *ui;

    Manager* manager;

    static QString i_toolPath;
    static QString i_cachePath;
};

#endif // MAINWINDOW_H
