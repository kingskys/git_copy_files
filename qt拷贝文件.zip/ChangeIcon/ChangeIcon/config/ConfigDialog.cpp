#include "ConfigDialog.h"
#include "ui_configdialog.h"
#include "qsettings.h"
#include "qfile.h"
#include "Manager.h"

// 游戏配置路径
QString i_path_config = "Release_ResConfig/Resources_original/LocalData/localgameconfig.plist";
// Info.plist 路径
QString i_path_info = "proj.ios_mac/ios/Info.plist";

ConfigDialog::ConfigDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConfigDialog)
{
    ui->setupUi(this);
}

ConfigDialog::~ConfigDialog()
{
    delete ui;
}

void ConfigDialog::setProductDir(QString dir) {
    ui->dir_product->setText(dir);
}

// 游戏配置
void ConfigDialog::setGameConfig(GameInfo info) {
    QString errMsg;
    QString productDir = ui->dir_product->text();
    QString  plistPath = productDir + i_path_config;
    if (QFile::exists(plistPath)) {
        QSettings setReg(plistPath, QSettings::NativeFormat);
        setReg.setValue("ID", info.productId);
        setReg.setValue("VERSION", info.version);
        setReg.setValue("KEY", info.appkey);
        setReg.setValue("SSL", info.ssl);
        setReg.setValue("check_view", info.shenhe);
    }
    else {
        errMsg.append("游戏配置文件不存在！\n");
    }

    plistPath = productDir + i_path_info;
    if (QFile::exists(plistPath)) {
        QSettings setInfo(plistPath, QSettings::NativeFormat);
        setInfo.setValue("CFBundleDisplayName", info.productName);
    }
    else {
        errMsg.append("Info.plist 文件不存在！\n");
    }

    if (errMsg.size() > 0) {
        Manager::alert(errMsg);
    }
    else {
        Manager::alert("success!");
    }
}

GameInfo ConfigDialog::getGameConfig() {
    GameInfo info;

    QString productDir = ui->dir_product->text();
    QString  plistPath = productDir + i_path_config;
    if (QFile::exists(plistPath)) {
        QSettings readReg(plistPath, QSettings::NativeFormat);

        info.productId = readReg.value("ID", QVariant()).toString();
        info.version = readReg.value("VERSION", QVariant()).toString();
        info.appkey = readReg.value("KEY", QVariant()).toString();
        info.ssl = readReg.value("SSL", QVariant()).toString();
        info.shenhe = readReg.value("check_view", QVariant()).toString();
    }
    else {
        info.errMsg.append("游戏配置文件不存在！\n");
    }

    plistPath = productDir + i_path_info;
    if (QFile::exists(plistPath)) {
        QSettings readInfo(plistPath, QSettings::NativeFormat);

        info.productName = readInfo.value("CFBundleDisplayName", QVariant()).toString();
    }
    else {
        info.errMsg.append("Info.plist 文件不存在！\n");
    }

    return info;
}



void ConfigDialog::on_readBtn_clicked() {
    QString productDir = ui->dir_product->text();
    if (!Manager::checkDir(productDir, "项目")) {
        return;
    }

    GameInfo info = this->getGameConfig();

    ui->product_version->setText(info.version);
    ui->product_name->setText(info.productName);
    ui->product_id->setText(info.productId);
    ui->product_appkey->setText(info.appkey);
    ui->check_ssl->setChecked(info.ssl == "1");
    ui->check_shenhe->setChecked(info.shenhe == "1");

    if (info.errMsg.size() > 0) {
        Manager::alert(info.errMsg);
    }
    else {
        Manager::alert("success!");
    }
}

void ConfigDialog::on_setBtn_clicked() {
    QString productDir = ui->dir_product->text();
    if (!Manager::checkDir(productDir, "项目")) {
        return;
    }

    GameInfo info;
    info.version = ui->product_version->text();
    info.productName = ui->product_name->text();
    info.productId = ui->product_id->text();
    info.appkey = ui->product_appkey->text();
    info.ssl = ui->check_ssl->isChecked() ? "1" : "0";
    info.shenhe = ui->check_shenhe->isChecked() ? "1" : "0";

    this->setGameConfig(info);
}
