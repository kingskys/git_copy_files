#ifndef CONFIGDIALOG_H
#define CONFIGDIALOG_H

#include <QDialog>

struct GameInfo {
    QString productName;
    QString productId;
    QString version;
    QString appkey;
    QString ssl;
    QString shenhe;
    QString errMsg;
};

namespace Ui {
class ConfigDialog;
}

class ConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ConfigDialog(QWidget *parent = 0);
    ~ConfigDialog();

    void setProductDir(QString dir);

    // 游戏配置
    void setGameConfig(GameInfo info);

    GameInfo getGameConfig();

private slots:


    void on_readBtn_clicked();

    void on_setBtn_clicked();

private:
    Ui::ConfigDialog *ui;
};

#endif // CONFIGDIALOG_H
