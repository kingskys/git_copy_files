#include "BJLDialog.h"
#include "ui_bjldialog.h"

BJLDialog::BJLDialog(QWidget *parent) :
    BaseDialog(parent),
    ui(new Ui::BJLDialog)
{
    ui->setupUi(this);

    i_bg_source = "Resources/res_baijiale/Baijiale/baijiale_beijing_check.png";
    i_bg_studio = "studio_pro/res_baijiale/cocosstudio/Baijiale/baijiale_beijing_check.png";
    i_targetPath = "studio_pro/res_baijiale/cocosstudio/";

}

BJLDialog::~BJLDialog()
{
    delete ui;
}

void BJLDialog::setProductDir(QString dir) {
    ui->dir_product->setText(dir);
}

void BJLDialog::updateProductDir() {
    this->productDir = ui->dir_product->text();
}

#pragma mark -
#pragma mark -

void BJLDialog::copyBgToResource(QString path) {
    this->copyFile(path, this->productDir+i_bg_source, "背景到resource");
}

void BJLDialog::copyBgToStudio(QString path) {
    this->copyFile(path, this->productDir+i_bg_studio, "背景到studio");
}

#pragma mark -
#pragma mark - 按钮事件

void BJLDialog::on_startBtn_clicked()
{
    this->manager->initData();
    this->updateProductDir();
    if (!Manager::checkDir(this->productDir, "项目")) {
        return;
    }

    this->copyBgToResource(ui->bg->text());
    this->copyBgToStudio(ui->bg->text());

    this->manager->showResultAlert();

}

void BJLDialog::on_targetBtn_clicked()
{
    this->openTargetDir();
}

void BJLDialog::on_bg_resource_clicked()
{
    this->openResourceBgDir();
}

void BJLDialog::on_bg_studio_clicked()
{
    this->openStudioBgDir();
}
