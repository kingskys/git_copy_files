#ifndef MANAGER_H
#define MANAGER_H

#include "qstring.h"

class Manager
{
public:
    Manager();

    void initData();

    int getErrNum();
    QString getErrMsg();

    QString getBuildMsg();


public:
    void copyFile(QString resourcePath, QString targetPath, QString tips);

    void showResultAlert();

public:

    static bool copyFileToPath(QString sourceDir, QString toDir, bool coverFileIfExist);

    static bool copyDirectoryFiles(const QString &fromDir, const QString &toDir, bool coverFileIfExist);

    static bool checkDir(QString dir, QString tips, bool showAlert = true);

    static bool checkFile(QString path, QString tips, bool showAlert = true);

    static void alert(QString msg);

    static bool openDir(QString dir);

    static bool openFile(QString path);

    static QString readFile(QString path);

    static bool writeFile(QString path, QString text);

private:
    int nErr;
    QString errMsg;

    QString buildMsg;

};

#endif // MANAGER_H
