#ifndef ICONDIALOG_H
#define ICONDIALOG_H

#include <QDialog>

namespace Ui {
class IconDialog;
}

class IconDialog : public QDialog
{
    Q_OBJECT

public:
    explicit IconDialog(QWidget *parent = 0);
    ~IconDialog();

    void initData();

    void setProductDir(QString dir);

protected:
    // app icon
    void copyAppIcon(QString dir);
    // 启动图
    void copyAppStart(QString dir);

    void showResultAlert();

private slots:
    void on_startBtn_clicked();

    void on_target_icon_clicked();

    void on_target_start_clicked();

private:
    Ui::IconDialog *ui;

    QString productDir;
    QString buildMsg;
    QString errMsg;
    int nErr;

private:
    // app icon目录
    static QString i_dir_icon;
    // 启动图目录
    static QString i_dir_start;
};

#endif // ICONDIALOG_H
