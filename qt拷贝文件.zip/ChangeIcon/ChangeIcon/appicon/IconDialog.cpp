#include "IconDialog.h"
#include "ui_icondialog.h"
#include "qdir.h"
#include "qfile.h"
#include "qfileinfo.h"
#include "Manager.h"

// app icon目录
QString IconDialog::i_dir_icon = "proj.ios_mac/Goldenfraud iOS/Images.xcassets/AppIcon.appiconset/";
// 启动图目录
QString IconDialog::i_dir_start = "proj.ios_mac/Goldenfraud iOS/Images.xcassets/Brand Assets.launchimage";


IconDialog::IconDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::IconDialog)
{
    ui->setupUi(this);
}

IconDialog::~IconDialog()
{
    delete ui;
}

void IconDialog::initData() {
    this->nErr = 0;
    this->errMsg.clear();
    this->buildMsg.clear();
    this->productDir.clear();
}

void IconDialog::setProductDir(QString dir) {
    ui->dir_product->setText(dir);
}

// app icon
void IconDialog::copyAppIcon(QString dir) {
    this->buildMsg.append("+++++++++++++ 开始 copy app icon\n");

    if (dir.length() == 0) {
        this->buildMsg.append("app icon path == null\n");
        return;
    }

    QDir sourceDir(dir);
    if (!sourceDir.exists()) {
        this->nErr++;
        this->errMsg.append("app icon 资源路径错误！！！\n");
        return;
    }

    QDir targetDir(this->productDir + i_dir_icon);
    if (!targetDir.exists()) {
        this->nErr++;
        this->errMsg.append("app icon 目标路径错误！！！\n");
        return;
    }

    QFileInfoList infoList = sourceDir.entryInfoList();
    foreach (QFileInfo fileInfo, infoList) {
        QString filename = fileInfo.fileName();
        if (filename.indexOf(".png") > 0) {
            if (targetDir.exists(filename)) {
                targetDir.remove(filename);
            }

            // 进行文件copy
            if(QFile::copy(fileInfo.filePath(), targetDir.filePath(filename))){
                this->buildMsg.append(filename + "   ");
            }
            else {
                this->errMsg.append(QString("\ncopy (%1) 文件错误！！！\n").arg(filename));
            }
        }
    }

    this->buildMsg.append("\n============ 结束 copy app icon\n\n");

}

// 启动图
void IconDialog::copyAppStart(QString dir) {
    this->buildMsg.append("+++++++++++++ 开始 copy 启动图\n");

    if (dir.length() == 0) {
        this->buildMsg.append("启动图 path == null\n");
        return;
    }

    QDir sourceDir(dir);
    if (!sourceDir.exists()) {
        this->nErr++;
        this->errMsg.append("启动图 资源路径错误！！！\n");
        return;
    }

    QDir targetDir(this->productDir + i_dir_start);
    if (!targetDir.exists()) {
        this->nErr++;
        this->errMsg.append("启动图 目标路径错误！！！\n");
        return;
    }

    QFileInfoList infoList = sourceDir.entryInfoList();
    foreach (QFileInfo fileInfo, infoList) {
        QString filename = fileInfo.fileName();
        if (filename.indexOf(".png") > 0) {
            QString targetFilename = filename;
            targetFilename.replace("×", "x");

            if (targetDir.exists(targetFilename)) {
                targetDir.remove(targetFilename);
            }

            // 进行文件copy
            if(QFile::copy(fileInfo.filePath(), targetDir.filePath(targetFilename))){
                this->buildMsg.append(targetFilename + "    ");
            }
            else {
                this->errMsg.append(QString("\ncopy (%1->%2) 文件错误！！！\n").arg(filename).arg(targetFilename));
            }
        }
    }

    this->buildMsg.append("============ 结束 copy 启动图\n\n");
}


void IconDialog::showResultAlert() {
    QString text;
    text.append(this->buildMsg);

    if (this->nErr > 0) {
        text.append("\n/************************************/\n");
        text.append(QString("error:%1\n").arg(this->nErr));
        text.append("ERROR:\n");
        text.append(this->errMsg);
    }
    else {
        text.append("success!\n");
    }

    Manager::alert(text);
}

void IconDialog::on_startBtn_clicked()
{
    this->initData();
    this->productDir = ui->dir_product->text();
    if (!Manager::checkDir(this->productDir, "项目")) {
        return;
    }

    this->copyAppIcon(ui->dir_icon->text());
    this->copyAppStart(ui->dir_start->text());

    this->showResultAlert();
}


void IconDialog::on_target_icon_clicked()
{
    QString productDir = ui->dir_product->text();
    if (!Manager::checkDir(productDir, "项目")) {
        return;
    }

    Manager::openDir(productDir + i_dir_icon);
}

void IconDialog::on_target_start_clicked()
{
    QString productDir = ui->dir_product->text();
    if (!Manager::checkDir(productDir, "项目")) {
        return;
    }

    Manager::openDir(productDir + i_dir_start);
}
