#ifndef PATHLINEEDIT_H
#define PATHLINEEDIT_H

#include <qlineedit.h>
#include <qwidget.h>
#include <QDrag>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QMimeData>


class PathLineEdit : public QLineEdit
{
    Q_OBJECT
public:
    explicit PathLineEdit(QWidget *parent = 0);
    ~PathLineEdit();

private slots:
    void dragEnterEvent(QDragEnterEvent *event);

    void dropEvent(QDropEvent *event);


};

#endif // PATHLINEEDIT_H
