#include "BRNNDialog.h"
#include "ui_brnndialog.h"

BRNNDialog::BRNNDialog(QWidget *parent) :
    BaseDialog(parent),
    ui(new Ui::BRNNDialog)
{
    ui->setupUi(this);

    i_targetPath = "studio_pro/res_niuniu100/cocosstudio/";
    i_bg_source = "Resources/res_niuniu100/100nncard/100nn_beijing_check.png";
    i_bg_studio = "studio_pro/res_niuniu100/cocosstudio/100nncard/100nn_beijing_check.png";

}

BRNNDialog::~BRNNDialog()
{
    delete ui;
}

void BRNNDialog::setProductDir(QString dir) {
    ui->dir_product->setText(dir);
}

void BRNNDialog::updateProductDir() {
    this->productDir = ui->dir_product->text();
}

#pragma mark -
#pragma mark -

void BRNNDialog::copyBgToResource(QString path) {
    this->copyFile(path, this->productDir+i_bg_source, "背景到resource");
}

void BRNNDialog::copyBgToStudio(QString path) {
    this->copyFile(path, this->productDir+i_bg_studio, "背景到studio");
}

#pragma mark -
#pragma mark - 按钮事件

void BRNNDialog::on_startBtn_clicked()
{
    this->manager->initData();
    this->updateProductDir();
    if (!Manager::checkDir(this->productDir, "项目")) {
        return;
    }

    this->copyBgToResource(ui->bg->text());
    this->copyBgToStudio(ui->bg->text());

    this->manager->showResultAlert();
}

void BRNNDialog::on_targetBtn_clicked()
{
    this->openTargetDir();
}


void BRNNDialog::on_bg_resource_clicked()
{
    this->openResourceBgDir();
}

void BRNNDialog::on_bg_studio_clicked()
{
    this->openStudioBgDir();
}
