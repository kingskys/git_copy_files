#ifndef BRNNDIALOG_H
#define BRNNDIALOG_H

#include "base/BaseDialog.h"

namespace Ui {
class BRNNDialog;
}

class BRNNDialog : public BaseDialog
{
    Q_OBJECT

public:
    explicit BRNNDialog(QWidget *parent = 0);
    ~BRNNDialog();

    void setProductDir(QString dir);

    void updateProductDir();

protected:
    void copyBgToResource(QString path);

    void copyBgToStudio(QString path);

private slots:
    void on_startBtn_clicked();

    void on_targetBtn_clicked();

    void on_bg_studio_clicked();

    void on_bg_resource_clicked();

private:
    Ui::BRNNDialog *ui;

};

#endif // BRNNDIALOG_H
