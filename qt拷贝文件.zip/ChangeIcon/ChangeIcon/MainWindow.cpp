#include "MainWindow.h"
#include "ui_mainwindow.h"
#include "qdir.h"
#include "qregexp.h"
#include "qstandardpaths.h"

QString MainWindow::i_toolPath = "tool/res_publish";
QString MainWindow::i_cachePath = "/product_dir";

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->cachePath = QStandardPaths::writableLocation(QStandardPaths::TempLocation) + i_cachePath;
    QString path = Manager::readFile(this->cachePath);
    QRegExp re("(\\S)+");
    if (path.indexOf(re) >= 0) {
        path = re.cap(0);
    }

    ui->dir_product->setText(path);
}

MainWindow::~MainWindow() {
    delete ui;
}


void MainWindow::on_view_ddz_clicked() {
    DDZDialog* dialog = new DDZDialog(this);
    dialog->show();

    dialog->setProductDir(ui->dir_product->text());
}

void MainWindow::on_view_config_clicked() {
    ConfigDialog* dialog = new ConfigDialog(this);
    dialog->show();

    dialog->setProductDir(ui->dir_product->text());
}


void MainWindow::on_view_logo_clicked()
{
    LogoDialog* dialog = new LogoDialog(this);
    dialog->show();

    dialog->setProductDir(ui->dir_product->text());
}

void MainWindow::on_view_icon_clicked()
{
    IconDialog* dialog = new IconDialog(this);
    dialog->show();

    dialog->setProductDir(ui->dir_product->text());
}

void MainWindow::on_view_hall_clicked()
{
    HallDialog* dialog = new HallDialog(this);
    dialog->show();

    dialog->setProductDir(ui->dir_product->text());
}

void MainWindow::on_view_tool_clicked()
{
    QString productDir = ui->dir_product->text();
    if (!Manager::checkDir(productDir, "项目")) {
        return;
    }

    Manager::openDir(productDir + i_toolPath);
}

void MainWindow::on_view_brnn_clicked()
{
    BRNNDialog* dialog = new BRNNDialog(this);
    dialog->show();

    dialog->setProductDir(ui->dir_product->text());
}

void MainWindow::on_record_clicked()
{
    if (Manager::writeFile(this->cachePath, ui->dir_product->text())) {
        Manager::alert("写入成功!");
    }
    else {
        Manager::alert("写入失败!");
    }
}

void MainWindow::on_view_zjh_clicked()
{
    ZJHDialog* dialog = new ZJHDialog(this);
    dialog->show();

    dialog->setProductDir(ui->dir_product->text());
}

void MainWindow::on_view_bjl_clicked()
{
    BJLDialog* dialog = new BJLDialog(this);
    dialog->show();

    dialog->setProductDir(ui->dir_product->text());
}
