#include "Manager.h"
#include "qfile.h"
#include "qdir.h"
#include "qfileinfo.h"
#include "qsettings.h"
#include "qmessagebox.h"
#include "qdesktopservices.h"
#include "qurl.h"
#include "qtextstream.h"

Manager::Manager() {

}

void Manager::initData() {
    this->nErr = 0;
    this->errMsg.clear();
    this->buildMsg.clear();
}

int Manager::getErrNum() {
    return this->nErr;
}

QString Manager::getErrMsg() {
    return this->errMsg;
}

QString Manager::getBuildMsg() {
    return this->buildMsg;
}



/************
 *
******/
void Manager::copyFile(QString resourcePath, QString targetPath, QString tips) {
    if (this->copyFileToPath(resourcePath, targetPath, true)) {
        this->buildMsg.append(QString("拷贝 %1 成功\n").arg(tips));
    }
    else {
        this->nErr++;
        this->errMsg.append(QString("拷贝 %1 失败\n").arg(tips));
    }
}

////////////////////////////////////////////////////////////

//拷贝文件：
bool Manager::copyFileToPath(QString sourceDir, QString toDir, bool coverFileIfExist) {
    if (sourceDir.length() == 0) {
        return false;
    }

    toDir.replace("\\", "/");
    if (sourceDir == toDir){
        return true;
    }

    if (!QFile::exists(sourceDir)){
        return false;
    }

    QDir *createfile = new QDir;
    bool exist = createfile->exists(toDir);

    if (exist) {
        if(coverFileIfExist) {
            createfile->remove(toDir);
        }
    } // end if

    if (!QFile::copy(sourceDir, toDir)) {
        return false;
    }

    return true;
}

//拷贝文件夹：
bool Manager::copyDirectoryFiles(const QString &fromDir, const QString &toDir, bool coverFileIfExist) {
    QDir sourceDir(fromDir);
    QDir targetDir(toDir);
    if (!targetDir.exists()) {    /**< 如果目标目录不存在，则进行创建 */
        if(!targetDir.mkdir(targetDir.absolutePath()))
            return false;
    }

    QFileInfoList fileInfoList = sourceDir.entryInfoList();
    foreach(QFileInfo fileInfo, fileInfoList) {
        if (fileInfo.fileName() == "." || fileInfo.fileName() == "..") {
            continue;
        }

        if (fileInfo.isDir()) {    /**< 当为目录时，递归的进行copy */
            if(!copyDirectoryFiles(fileInfo.filePath(),
                targetDir.filePath(fileInfo.fileName()),
                coverFileIfExist))
                return false;
        }
        else {            /**< 当允许覆盖操作时，将旧文件进行删除操作 */
            if(coverFileIfExist && targetDir.exists(fileInfo.fileName())) {
                targetDir.remove(fileInfo.fileName());
            }

            /// 进行文件copy
            if(!QFile::copy(fileInfo.filePath(),
                targetDir.filePath(fileInfo.fileName()))){
                    return false;
            }
        }
    }

    return true;
}

void Manager::showResultAlert() {
    QString text;
    text.append(this->getBuildMsg());

    if (this->getErrNum() > 0) {
        text.append("\n/************************************/\n");
        text.append(QString("error:%1\n").arg(this->getErrNum()));
        text.append("ERROR:\n");
        text.append(this->getErrMsg());
    }
    else {
        text.append("success!\n");
    }


    QMessageBox::information(NULL, "", text);
}


bool Manager::checkDir(QString dirtext, QString tips, bool showAlert) {
    if (dirtext.length() == 0) {
        if (showAlert) {
            QMessageBox::critical(NULL, "错误！", QString("%1 路径不可以为空！").arg(tips));
        }

        return false;
    } else {
        QDir dir(dirtext);
        if (!dir.exists()) {
            if (showAlert) {
                QMessageBox::critical(NULL, "错误！", QString("%1 路径不存在！").arg(tips));
            }

            return false;
        }
    }

    return true;
}

bool Manager::checkFile(QString path, QString tips, bool showAlert) {
    if (path.length() == 0) {
        if (showAlert) {
            QMessageBox::critical(NULL, "错误！", QString("%1 路径为空！").arg(tips));
        }

        return false;
    }

    if (!QFile::exists(path)){
        if (showAlert) {
            QMessageBox::critical(NULL, "错误！", QString("%1 不存在！").arg(tips));
        }

        return false;
    }

    return true;
}

void Manager::alert(QString msg) {
    QMessageBox::critical(NULL, "", msg);
}

bool Manager::openDir(QString dir) {
    if (dir.length() == 0) {
        return false;
    }

    QDir dirObj(dir);
    if (!dirObj.exists()) {
        return false;
    }

    QDesktopServices::openUrl(QUrl::fromLocalFile(dir));

    return true;
}

bool Manager::openFile(QString path) {
    if (path.length() == 0) {
        return false;
    }

    QFile file(path);
    if (!file.exists()) {
        return false;
    }

    QDesktopServices::openUrl(QUrl::fromLocalFile(path));

    return true;
}

QString Manager::readFile(QString path) {
    if (path.length() == 0) {
        return "";
    }

    QFile file(path);
    if (!file.open(QFile::ReadOnly | QFile::Text)) {
        return "";
    }

    qDebug("path:%s", qPrintable(path));

    QTextStream stream(&file);
    QString text = stream.readAll();

    file.close();

    return text;
}

bool Manager::writeFile(QString path, QString text) {
    if (path.length() == 0) {
        return false;
    }

    QFile file(path);
    if (!file.open(QFile::WriteOnly | QFile::Text)) {
        return false;
    }

    QTextStream stream(&file);

    stream << text << endl;

    file.close();

    return true;
}
