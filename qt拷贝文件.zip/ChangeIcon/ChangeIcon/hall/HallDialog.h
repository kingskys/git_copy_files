#ifndef HALLDIALOG_H
#define HALLDIALOG_H

#include <QDialog>
#include "base/BaseDialog.h"

namespace Ui {
class HallDialog;
}

class HallDialog : public BaseDialog
{
    Q_OBJECT

public:
    explicit HallDialog(QWidget *parent = 0);
    ~HallDialog();

    void setProductDir(QString dir);

    void updateProductDir();

protected:
    void copyBg(QString path);
    void copyBottomBar(QString path);
    void copyHeadBg(QString path);
    void copyHeadIcon(QString path);

    void copyGoldIcon(QString path);
    void copyGoldBg(QString path);
    void copyBtnRecharge(QString path);
    void copyBtnBack(QString path);

    void copyRoom1(QString path);
    void copyRoom2(QString path);
    void copyRoom3(QString path);
    void copyRoom4(QString path);

    void copyGameDDZ(QString path);
    void copyGameZJH(QString path);
    void copyGameBRNN(QString path);
    void copyGameBJL(QString path);

private slots:
    void on_targetBtn_clicked();

    void on_startBtn_clicked();

private:
    Ui::HallDialog *ui;

private:
    static QString i_img_bg;
    static QString i_img_bottom_bar;
    static QString i_img_head_bg;
    static QString i_img_head_icon;

    static QString i_img_gold_bg;
    static QString i_img_gold_icon;
    static QString i_img_btn_recharge;
    static QString i_img_btn_back;

    static QString i_img_room1;
    static QString i_img_room2;
    static QString i_img_room3;
    static QString i_img_room4;

    static QString i_img_game_ddz;
    static QString i_img_game_zjh;
    static QString i_img_game_brnn;
    static QString i_img_game_bjl;

};

#endif // HALLDIALOG_H
