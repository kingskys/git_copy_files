#include "HallDialog.h"
#include "ui_halldialog.h"
#include "qdesktopservices.h"
#include "qurl.h"

QString HallDialog::i_img_bg = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/bg.png";
QString HallDialog::i_img_bottom_bar = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/bar_bottom.png";
QString HallDialog::i_img_head_bg = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/head_bg.png";
QString HallDialog::i_img_head_icon = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/head_icon.png";

QString HallDialog::i_img_gold_bg = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/gold_frame.png";
QString HallDialog::i_img_gold_icon = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/gold_icon.png";
QString HallDialog::i_img_btn_recharge = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/btn_recharge.png";
QString HallDialog::i_img_btn_back = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/btn_back.png";

QString HallDialog::i_img_room1 = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/room_1.png";
QString HallDialog::i_img_room2 = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/room_2.png";
QString HallDialog::i_img_room3 = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/room_3.png";
QString HallDialog::i_img_room4 = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/room_4.png";

QString HallDialog::i_img_game_ddz = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/img_ddz.png";
QString HallDialog::i_img_game_zjh = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/img_zjh.png";
QString HallDialog::i_img_game_brnn = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/img_hundred_nn.png";
QString HallDialog::i_img_game_bjl = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/img_bjl.png";


HallDialog::HallDialog(QWidget *parent) :
    BaseDialog(parent),
    ui(new Ui::HallDialog)
{
    ui->setupUi(this);

    i_targetPath = "studio_pro/res_hallex/cocosstudio/res_hallex_cs/hallex/";
}

HallDialog::~HallDialog()
{
    delete ui;
}

void HallDialog::setProductDir(QString dir) {
    ui->dir_product->setText(dir);
}

void HallDialog::updateProductDir() {
    this->productDir = ui->dir_product->text();
}


void HallDialog::copyBg(QString path) {
    this->copyFile(path, this->productDir+i_img_bg, "背景图");
}

void HallDialog::copyBottomBar(QString path) {
    this->copyFile(path, this->productDir+i_img_bottom_bar, "底条");
}

void HallDialog::copyHeadBg(QString path) {
    this->copyFile(path, this->productDir+i_img_head_bg, "头像底");
}

void HallDialog::copyHeadIcon(QString path) {
    this->copyFile(path, this->productDir+i_img_head_icon, "头像");
}

void HallDialog::copyGoldIcon(QString path) {
    this->copyFile(path, this->productDir+i_img_gold_icon, "金币");
}

void HallDialog::copyGoldBg(QString path) {
    this->copyFile(path, this->productDir+i_img_gold_bg, "金币底");
}

void HallDialog::copyBtnRecharge(QString path) {
    this->copyFile(path, this->productDir+i_img_btn_recharge, "充值按钮");
}

void HallDialog::copyBtnBack(QString path) {
    this->copyFile(path, this->productDir+i_img_btn_back, "返回按钮");
}

void HallDialog::copyRoom1(QString path) {
    this->copyFile(path, this->productDir+i_img_room1, "房间1");
}

void HallDialog::copyRoom2(QString path) {
    this->copyFile(path, this->productDir+i_img_room2, "房间2");
}

void HallDialog::copyRoom3(QString path) {
    this->copyFile(path, this->productDir+i_img_room3, "房间3");
}

void HallDialog::copyRoom4(QString path) {
    this->copyFile(path, this->productDir+i_img_room4, "房间4");
}

void HallDialog::copyGameDDZ(QString path) {
    this->copyFile(path, this->productDir+i_img_game_ddz, "斗地主");
}

void HallDialog::copyGameZJH(QString path) {
    this->copyFile(path, this->productDir+i_img_game_zjh, "炸金花");
}

void HallDialog::copyGameBRNN(QString path) {
    this->copyFile(path, this->productDir+i_img_game_brnn, "百人牛牛");
}

void HallDialog::copyGameBJL(QString path) {
    this->copyFile(path, this->productDir+i_img_game_bjl, "百家乐");
}

void HallDialog::on_targetBtn_clicked()
{
    this->openTargetDir();
}

void HallDialog::on_startBtn_clicked()
{
    this->manager->initData();
    this->updateProductDir();
    if (!Manager::checkDir(this->productDir, "项目")) {
        return;
    }

    this->copyBg(ui->bg->text());
    this->copyBottomBar(ui->bottom->text());
    this->copyHeadBg(ui->head_bg->text());
    this->copyHeadIcon(ui->head_icon->text());

    this->copyGoldIcon(ui->icon_gold->text());
    this->copyGoldBg(ui->icon_gold_bg->text());
    this->copyBtnRecharge(ui->btn_recharge->text());
    this->copyBtnBack(ui->btn_back->text());

    this->copyRoom1(ui->room_1->text());
    this->copyRoom2(ui->room_2->text());
    this->copyRoom3(ui->room_3->text());
    this->copyRoom4(ui->room_4->text());

    this->copyGameDDZ(ui->game_ddz->text());
    this->copyGameZJH(ui->game_zjh->text());
    this->copyGameBRNN(ui->game_brnn->text());
    this->copyGameBJL(ui->game_bjl->text());

    this->manager->showResultAlert();
}


