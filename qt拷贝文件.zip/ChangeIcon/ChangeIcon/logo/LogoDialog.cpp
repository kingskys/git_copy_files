#include "LogoDialog.h"
#include "ui_logodialog.h"


// 大厅logo路径
QString LogoDialog::i_logo_hall = "studio_pro/res_hall/cocosstudio/res_hall_cs/hall_1152/hall_logo_icon.png";
// 网络不可用logo
QString LogoDialog::i_logo_net = "studio_pro/res_hall/cocosstudio/res_hall_cs/hall/hall_ruowang_tips.png";
// 加载界面logo
QString LogoDialog::i_logo_loading = "studio_pro/res_loading/cocosstudio/loading/loading_icon.png";
// 下载界面logo
QString LogoDialog::i_logo_download = "studio_pro/res_hall/cocosstudio/res_hall_cs/download/download_res_loading_bg.png";
// 下载界面logo(暗色)
QString LogoDialog::i_logo_download_dark = "studio_pro/res_hall/cocosstudio/res_hall_cs/download/download_res_loading_bar.png";

// 大厅背景
QString LogoDialog::i_bg_hall = "studio_pro/res_hall/cocosstudio/res_hall_cs/hall_1152/hall_view_background.png";
// 加载界面背景
QString LogoDialog::i_bg_loading = "studio_pro/res_loading/cocosstudio/loading/lodbj.png";
// 下载界面背景
QString LogoDialog::i_bg_download = "studio_pro/res_hall/cocosstudio/res_hall_cs/download/download_res_bg.png";

// 目标路径
QString LogoDialog::i_targetPath = "studio_pro/";

LogoDialog::LogoDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LogoDialog)
{
    ui->setupUi(this);
    this->manager = new Manager();
}

LogoDialog::~LogoDialog()
{
    if (this->manager) {
        delete this->manager;
        this->manager = nullptr;
    }

    delete ui;
}

void LogoDialog::setProductDir(QString dir) {
    ui->dir_product->setText(dir);
}

// logo
void LogoDialog::copyHallLogo(QString path) {
    this->copyFile(path, this->productDir+i_logo_hall, "大厅logo");
}

void LogoDialog::copyNetLogo(QString path) {
    this->copyFile(path, this->productDir+i_logo_net, "网络不可用logo");
}

void LogoDialog::copyLoadingLogo(QString path) {
    this->copyFile(path, this->productDir+i_logo_loading, "加载logo");
}

void LogoDialog::copyDownloadLightLogo(QString path) {
    this->copyFile(path, this->productDir+i_logo_download, "亮下载logo");
}

void LogoDialog::copyDownloadDarkLogo(QString path) {
    this->copyFile(path, this->productDir+i_logo_download_dark, "暗下载logo");
}

// 背景
void LogoDialog::copyHallBg(QString path) {
    this->copyFile(path, this->productDir+i_bg_hall, "大厅背景");
}

void LogoDialog::copyLoadingBg(QString path) {
    this->copyFile(path, this->productDir+i_bg_loading, "加载背景");
}

void LogoDialog::copyDownloadBg(QString path) {
    this->copyFile(path, this->productDir+i_bg_download, "下载背景");
}

void LogoDialog::copyFile(QString resourcePath, QString targetPath, QString tips) {
    this->manager->copyFile(resourcePath, targetPath, tips);
}


void LogoDialog::on_startBtn_clicked() {
    this->manager->initData();
    this->productDir = ui->dir_product->text();
    if (!Manager::checkDir(this->productDir, "项目")) {
        return;
    }

    this->copyHallLogo(ui->logo_hall->text());
    this->copyLoadingLogo(ui->logo_big->text());
    this->copyDownloadLightLogo(ui->logo_big_left_light->text());
    this->copyDownloadDarkLogo(ui->logo_big_left_dark->text());
    this->copyNetLogo(ui->logo_big->text());

    this->copyHallBg(ui->bg_hall->text());
    this->copyDownloadBg(ui->bg_loading->text());
    this->copyLoadingBg(ui->bg_loading->text());

    this->manager->showResultAlert();
}

void LogoDialog::on_targetBtn_clicked()
{
    QString productDir = ui->dir_product->text();
    if (!Manager::checkDir(productDir, "项目")) {
        return;
    }

    Manager::openDir(productDir + i_targetPath);
}
