#ifndef LOGODIALOG_H
#define LOGODIALOG_H

#include <QDialog>
#include "Manager.h"

namespace Ui {
class LogoDialog;
}

class LogoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LogoDialog(QWidget *parent = 0);
    ~LogoDialog();

    void setProductDir(QString dir);

protected:
    // logo
    void copyHallLogo(QString path);
    void copyNetLogo(QString path);
    void copyLoadingLogo(QString path);
    void copyDownloadLightLogo(QString path);
    void copyDownloadDarkLogo(QString path);

    // 背景
    void copyHallBg(QString path);
    void copyLoadingBg(QString path);
    void copyDownloadBg(QString path);

    void copyFile(QString resourcePath, QString targetPath, QString tips);

private slots:
    void on_startBtn_clicked();

    void on_targetBtn_clicked();

private:
    Ui::LogoDialog *ui;

    QString productDir;
    Manager* manager;

private:
    // 大厅logo路径
    static QString i_logo_hall;
    // 网络不可用logo
    static QString i_logo_net;
    // 加载界面logo
    static QString i_logo_loading;
    // 下载界面logo
    static QString i_logo_download;
    // 下载界面logo(暗色)
    static QString i_logo_download_dark;

    // 大厅背景
    static QString i_bg_hall;
    // 加载界面背景
    static QString i_bg_loading;
    // 下载界面背景
    static QString i_bg_download;
    // 目标路径
    static QString i_targetPath;
};

#endif // LOGODIALOG_H
