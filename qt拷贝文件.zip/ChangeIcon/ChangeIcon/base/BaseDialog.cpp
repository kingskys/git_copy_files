#include "BaseDialog.h"
#include "qfileinfo.h"
#include "qdir.h"

QString BaseDialog::i_targetPath = "";
QString BaseDialog::i_bg_source = "";
QString BaseDialog::i_bg_studio = "";

BaseDialog::BaseDialog(QWidget *parent) :
    QDialog(parent)
{
    this->manager = new Manager();
}

BaseDialog::~BaseDialog()
{
    if (this->manager) {
        delete this->manager;
        this->manager = nullptr;
    }
}

void BaseDialog::copyFile(QString resourcePath, QString targetPath, QString tips) {
    this->manager->copyFile(resourcePath, targetPath, tips);
}

// 打开目标文件夹
void BaseDialog::openTargetDir() {
    this->updateProductDir();
    if (!Manager::checkDir(this->productDir, "项目")) {
        return;
    }

    if (i_targetPath.size() == 0) {
        Manager::alert("没有配置 目标路径！");
        return;
    }

    Manager::openDir(productDir + i_targetPath);
}

// 打开resource目录下的背景文件夹
void BaseDialog::openResourceBgDir() {
    this->updateProductDir();
    if (!Manager::checkDir(this->productDir, "项目")) {
        return;
    }

    if (i_bg_source.size() == 0) {
        Manager::alert("没有配置 resource背景文件路径！");
        return;
    }

    QString path = this->productDir + i_bg_source;
    if (!Manager::checkFile(path, "resource背景文件")) {
        return;
    }

    QFileInfo info(path);
    QString dir = info.dir().absolutePath();
    Manager::openDir(dir);
    Manager::openFile(path);
}

// 打开studio目录下的背景文件夹
void BaseDialog::openStudioBgDir() {
    this->updateProductDir();
    if (!Manager::checkDir(this->productDir, "项目")) {
        return;
    }

    if (i_bg_studio.size() == 0) {
        Manager::alert("没有配置 studio中的背景文件路径！");
        return;
    }

    QString path = this->productDir + i_bg_studio;
    if (!Manager::checkFile(path, "studio中的背景文件")) {
        return;
    }

    QFileInfo info(path);
    QString dir = info.dir().absolutePath();
    Manager::openDir(dir);
    Manager::openFile(path);

}
