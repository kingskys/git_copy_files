#ifndef BASEDIALOG_H
#define BASEDIALOG_H

#include <QDialog>
#include "Manager.h"

class BaseDialog : public QDialog
{
public:
    explicit BaseDialog(QWidget *parent = 0);
    ~BaseDialog();

    virtual void setProductDir(QString dir) = 0;

    virtual void updateProductDir() = 0;

protected:
    void copyFile(QString resourcePath, QString targetPath, QString tips);

    // 打开目标文件夹
    void openTargetDir();
    // 打开resource目录下的背景文件夹
    void openResourceBgDir();
    // 打开studio目录下的背景文件夹
    void openStudioBgDir();

protected:
    Manager* manager;

    QString productDir;

protected:
    static QString i_targetPath;
    static QString i_bg_source;
    static QString i_bg_studio;

};

#endif // BASEDIALOG_H
