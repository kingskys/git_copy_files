/********************************************************************************
** Form generated from reading UI file 'ddzdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DDZDIALOG_H
#define UI_DDZDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include "PathLineEdit.h"

QT_BEGIN_NAMESPACE

class Ui_DDZDialog
{
public:
    PathLineEdit *dir_product;
    QLabel *label;
    PathLineEdit *bg;
    QLabel *label_2;
    QPushButton *startBtn;
    QLabel *label_3;
    QPushButton *targetBtn;
    QPushButton *bg_studio;
    QPushButton *bg_resource;

    void setupUi(QDialog *DDZDialog)
    {
        if (DDZDialog->objectName().isEmpty())
            DDZDialog->setObjectName(QStringLiteral("DDZDialog"));
        DDZDialog->resize(600, 300);
        dir_product = new PathLineEdit(DDZDialog);
        dir_product->setObjectName(QStringLiteral("dir_product"));
        dir_product->setGeometry(QRect(110, 60, 440, 30));
        QFont font;
        font.setPointSize(18);
        dir_product->setFont(font);
        label = new QLabel(DDZDialog);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(-10, 60, 100, 30));
        label->setFont(font);
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        bg = new PathLineEdit(DDZDialog);
        bg->setObjectName(QStringLiteral("bg"));
        bg->setGeometry(QRect(110, 120, 361, 30));
        bg->setFont(font);
        label_2 = new QLabel(DDZDialog);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(-10, 120, 100, 30));
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        startBtn = new QPushButton(DDZDialog);
        startBtn->setObjectName(QStringLiteral("startBtn"));
        startBtn->setGeometry(QRect(140, 200, 113, 60));
        QFont font1;
        font1.setPointSize(22);
        startBtn->setFont(font1);
        startBtn->setCursor(QCursor(Qt::PointingHandCursor));
        startBtn->setStyleSheet(QStringLiteral("color:rgb(255, 48, 67)"));
        label_3 = new QLabel(DDZDialog);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(260, 10, 100, 40));
        QFont font2;
        font2.setFamily(QStringLiteral("Kaiti SC"));
        font2.setPointSize(30);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(50);
        label_3->setFont(font2);
        label_3->setStyleSheet(QLatin1String("font: 30pt \"Kaiti SC\";color: rgb(255, 0, 0)\n"
""));
        label_3->setAlignment(Qt::AlignCenter);
        targetBtn = new QPushButton(DDZDialog);
        targetBtn->setObjectName(QStringLiteral("targetBtn"));
        targetBtn->setGeometry(QRect(350, 200, 113, 60));
        targetBtn->setFont(font1);
        targetBtn->setCursor(QCursor(Qt::PointingHandCursor));
        targetBtn->setStyleSheet(QStringLiteral("color:rgb(86, 37, 255)"));
        bg_studio = new QPushButton(DDZDialog);
        bg_studio->setObjectName(QStringLiteral("bg_studio"));
        bg_studio->setGeometry(QRect(10, 240, 113, 60));
        bg_studio->setFont(font1);
        bg_studio->setCursor(QCursor(Qt::PointingHandCursor));
        bg_studio->setStyleSheet(QStringLiteral("color:rgb(86, 37, 255)"));
        bg_resource = new QPushButton(DDZDialog);
        bg_resource->setObjectName(QStringLiteral("bg_resource"));
        bg_resource->setGeometry(QRect(480, 240, 113, 60));
        bg_resource->setFont(font1);
        bg_resource->setCursor(QCursor(Qt::PointingHandCursor));
        bg_resource->setStyleSheet(QStringLiteral("color:rgb(86, 37, 255)"));

        retranslateUi(DDZDialog);

        QMetaObject::connectSlotsByName(DDZDialog);
    } // setupUi

    void retranslateUi(QDialog *DDZDialog)
    {
        DDZDialog->setWindowTitle(QApplication::translate("DDZDialog", "\346\226\227\345\234\260\344\270\273", Q_NULLPTR));
        label->setText(QApplication::translate("DDZDialog", "\345\267\245\347\250\213\347\233\256\345\275\225", Q_NULLPTR));
        label_2->setText(QApplication::translate("DDZDialog", "\350\203\214\346\231\257", Q_NULLPTR));
        startBtn->setText(QApplication::translate("DDZDialog", "\345\274\200\345\247\213", Q_NULLPTR));
        label_3->setText(QApplication::translate("DDZDialog", "\346\226\227\345\234\260\344\270\273", Q_NULLPTR));
        targetBtn->setText(QApplication::translate("DDZDialog", "\347\233\256\346\240\207", Q_NULLPTR));
        bg_studio->setText(QApplication::translate("DDZDialog", "studio", Q_NULLPTR));
        bg_resource->setText(QApplication::translate("DDZDialog", "resource", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class DDZDialog: public Ui_DDZDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DDZDIALOG_H
