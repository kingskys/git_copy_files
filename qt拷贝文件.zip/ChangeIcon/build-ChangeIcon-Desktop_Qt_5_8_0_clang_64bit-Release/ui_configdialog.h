/********************************************************************************
** Form generated from reading UI file 'configdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONFIGDIALOG_H
#define UI_CONFIGDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include "PathLineEdit.h"

QT_BEGIN_NAMESPACE

class Ui_ConfigDialog
{
public:
    QLabel *label_5;
    QLabel *label_3;
    QLineEdit *product_version;
    QLabel *label_2;
    QLineEdit *product_name;
    QLineEdit *product_id;
    QCheckBox *check_shenhe;
    QCheckBox *check_ssl;
    PathLineEdit *dir_product;
    QLineEdit *product_appkey;
    QLabel *label_4;
    QLabel *label_6;
    QPushButton *readBtn;
    QPushButton *setBtn;

    void setupUi(QDialog *ConfigDialog)
    {
        if (ConfigDialog->objectName().isEmpty())
            ConfigDialog->setObjectName(QStringLiteral("ConfigDialog"));
        ConfigDialog->resize(600, 300);
        label_5 = new QLabel(ConfigDialog);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(30, 70, 59, 30));
        QFont font;
        font.setPointSize(18);
        label_5->setFont(font);
        label_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_3 = new QLabel(ConfigDialog);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(300, 70, 59, 30));
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        product_version = new QLineEdit(ConfigDialog);
        product_version->setObjectName(QStringLiteral("product_version"));
        product_version->setGeometry(QRect(110, 120, 60, 30));
        product_version->setFont(font);
        label_2 = new QLabel(ConfigDialog);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 120, 59, 30));
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        product_name = new QLineEdit(ConfigDialog);
        product_name->setObjectName(QStringLiteral("product_name"));
        product_name->setGeometry(QRect(110, 70, 150, 30));
        product_name->setFont(font);
        product_id = new QLineEdit(ConfigDialog);
        product_id->setObjectName(QStringLiteral("product_id"));
        product_id->setGeometry(QRect(380, 70, 80, 30));
        product_id->setFont(font);
        check_shenhe = new QCheckBox(ConfigDialog);
        check_shenhe->setObjectName(QStringLiteral("check_shenhe"));
        check_shenhe->setGeometry(QRect(310, 125, 130, 20));
        check_shenhe->setFont(font);
        check_shenhe->setCursor(QCursor(Qt::PointingHandCursor));
        check_ssl = new QCheckBox(ConfigDialog);
        check_ssl->setObjectName(QStringLiteral("check_ssl"));
        check_ssl->setGeometry(QRect(240, 125, 60, 20));
        check_ssl->setFont(font);
        check_ssl->setCursor(QCursor(Qt::PointingHandCursor));
        check_ssl->setChecked(true);
        check_ssl->setTristate(false);
        dir_product = new PathLineEdit(ConfigDialog);
        dir_product->setObjectName(QStringLiteral("dir_product"));
        dir_product->setGeometry(QRect(110, 20, 431, 30));
        dir_product->setFont(font);
        dir_product->setCursor(QCursor(Qt::IBeamCursor));
        dir_product->setFocusPolicy(Qt::StrongFocus);
        dir_product->setDragEnabled(false);
        product_appkey = new QLineEdit(ConfigDialog);
        product_appkey->setObjectName(QStringLiteral("product_appkey"));
        product_appkey->setGeometry(QRect(110, 170, 431, 30));
        product_appkey->setFont(font);
        product_appkey->setFocusPolicy(Qt::StrongFocus);
        label_4 = new QLabel(ConfigDialog);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(30, 170, 59, 30));
        label_4->setFont(font);
        label_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_6 = new QLabel(ConfigDialog);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(8, 20, 81, 30));
        label_6->setFont(font);
        label_6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        readBtn = new QPushButton(ConfigDialog);
        readBtn->setObjectName(QStringLiteral("readBtn"));
        readBtn->setGeometry(QRect(100, 220, 113, 60));
        QFont font1;
        font1.setPointSize(22);
        readBtn->setFont(font1);
        readBtn->setCursor(QCursor(Qt::PointingHandCursor));
        setBtn = new QPushButton(ConfigDialog);
        setBtn->setObjectName(QStringLiteral("setBtn"));
        setBtn->setGeometry(QRect(360, 220, 113, 60));
        setBtn->setFont(font1);
        setBtn->setCursor(QCursor(Qt::PointingHandCursor));

        retranslateUi(ConfigDialog);

        QMetaObject::connectSlotsByName(ConfigDialog);
    } // setupUi

    void retranslateUi(QDialog *ConfigDialog)
    {
        ConfigDialog->setWindowTitle(QApplication::translate("ConfigDialog", "\346\270\270\346\210\217\351\205\215\347\275\256", Q_NULLPTR));
        label_5->setText(QApplication::translate("ConfigDialog", "\344\272\247\345\223\201\345\220\215", Q_NULLPTR));
        label_3->setText(QApplication::translate("ConfigDialog", "\344\272\247\345\223\201id", Q_NULLPTR));
        product_version->setText(QApplication::translate("ConfigDialog", "1", Q_NULLPTR));
        product_version->setPlaceholderText(QApplication::translate("ConfigDialog", "\347\211\210\346\234\254", Q_NULLPTR));
        label_2->setText(QApplication::translate("ConfigDialog", "\347\211\210\346\234\254", Q_NULLPTR));
        product_name->setPlaceholderText(QApplication::translate("ConfigDialog", "\344\272\247\345\223\201\345\220\215\347\247\260", Q_NULLPTR));
        product_id->setPlaceholderText(QApplication::translate("ConfigDialog", "\344\272\247\345\223\201id", Q_NULLPTR));
        check_shenhe->setText(QApplication::translate("ConfigDialog", "\345\256\241\346\240\270\347\225\214\351\235\242", Q_NULLPTR));
        check_ssl->setText(QApplication::translate("ConfigDialog", "\345\212\240\345\257\206", Q_NULLPTR));
        dir_product->setPlaceholderText(QApplication::translate("ConfigDialog", "\345\267\245\347\250\213\347\233\256\345\275\225", Q_NULLPTR));
        product_appkey->setText(QString());
        product_appkey->setPlaceholderText(QApplication::translate("ConfigDialog", "app key", Q_NULLPTR));
        label_4->setText(QApplication::translate("ConfigDialog", "appkey", Q_NULLPTR));
        label_6->setText(QApplication::translate("ConfigDialog", "\345\267\245\347\250\213\347\233\256\345\275\225", Q_NULLPTR));
        readBtn->setText(QApplication::translate("ConfigDialog", "\350\257\273\345\217\226", Q_NULLPTR));
        setBtn->setText(QApplication::translate("ConfigDialog", "\345\206\231\345\205\245", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ConfigDialog: public Ui_ConfigDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONFIGDIALOG_H
