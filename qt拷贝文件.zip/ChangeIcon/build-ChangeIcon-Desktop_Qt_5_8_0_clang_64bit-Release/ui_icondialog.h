/********************************************************************************
** Form generated from reading UI file 'icondialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ICONDIALOG_H
#define UI_ICONDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include "PathLineEdit.h"

QT_BEGIN_NAMESPACE

class Ui_IconDialog
{
public:
    PathLineEdit *dir_icon;
    PathLineEdit *dir_start;
    PathLineEdit *dir_product;
    QPushButton *startBtn;
    QPushButton *target_icon;
    QPushButton *target_start;

    void setupUi(QDialog *IconDialog)
    {
        if (IconDialog->objectName().isEmpty())
            IconDialog->setObjectName(QStringLiteral("IconDialog"));
        IconDialog->resize(600, 300);
        dir_icon = new PathLineEdit(IconDialog);
        dir_icon->setObjectName(QStringLiteral("dir_icon"));
        dir_icon->setGeometry(QRect(60, 100, 431, 30));
        QFont font;
        font.setPointSize(18);
        dir_icon->setFont(font);
        dir_icon->setCursor(QCursor(Qt::IBeamCursor));
        dir_icon->setFocusPolicy(Qt::StrongFocus);
        dir_icon->setDragEnabled(false);
        dir_start = new PathLineEdit(IconDialog);
        dir_start->setObjectName(QStringLiteral("dir_start"));
        dir_start->setGeometry(QRect(60, 140, 431, 30));
        dir_start->setFont(font);
        dir_start->setCursor(QCursor(Qt::IBeamCursor));
        dir_start->setFocusPolicy(Qt::StrongFocus);
        dir_start->setDragEnabled(false);
        dir_product = new PathLineEdit(IconDialog);
        dir_product->setObjectName(QStringLiteral("dir_product"));
        dir_product->setGeometry(QRect(60, 30, 481, 30));
        dir_product->setFont(font);
        dir_product->setCursor(QCursor(Qt::IBeamCursor));
        dir_product->setFocusPolicy(Qt::StrongFocus);
        dir_product->setDragEnabled(false);
        startBtn = new QPushButton(IconDialog);
        startBtn->setObjectName(QStringLiteral("startBtn"));
        startBtn->setGeometry(QRect(250, 210, 113, 60));
        QFont font1;
        font1.setPointSize(22);
        startBtn->setFont(font1);
        startBtn->setCursor(QCursor(Qt::PointingHandCursor));
        startBtn->setStyleSheet(QStringLiteral("color:rgb(255, 73, 151)"));
        target_icon = new QPushButton(IconDialog);
        target_icon->setObjectName(QStringLiteral("target_icon"));
        target_icon->setGeometry(QRect(500, 90, 91, 51));
        target_icon->setCursor(QCursor(Qt::PointingHandCursor));
        target_icon->setStyleSheet(QStringLiteral("font: 26pt \"STKaiti\";color:rgb(112, 63, 255)"));
        target_start = new QPushButton(IconDialog);
        target_start->setObjectName(QStringLiteral("target_start"));
        target_start->setGeometry(QRect(500, 130, 91, 51));
        target_start->setCursor(QCursor(Qt::PointingHandCursor));
        target_start->setStyleSheet(QStringLiteral("font: 26pt \"STKaiti\";color:rgb(112, 63, 255)"));

        retranslateUi(IconDialog);

        QMetaObject::connectSlotsByName(IconDialog);
    } // setupUi

    void retranslateUi(QDialog *IconDialog)
    {
        IconDialog->setWindowTitle(QApplication::translate("IconDialog", "appIcon\345\222\214\345\220\257\345\212\250\345\233\276", Q_NULLPTR));
        dir_icon->setPlaceholderText(QApplication::translate("IconDialog", "icon\347\233\256\345\275\225", Q_NULLPTR));
        dir_start->setPlaceholderText(QApplication::translate("IconDialog", "\345\220\257\345\212\250\345\233\276\347\233\256\345\275\225", Q_NULLPTR));
        dir_product->setPlaceholderText(QApplication::translate("IconDialog", "\345\267\245\347\250\213\347\233\256\345\275\225", Q_NULLPTR));
        startBtn->setText(QApplication::translate("IconDialog", "\345\274\200\345\247\213", Q_NULLPTR));
        target_icon->setText(QApplication::translate("IconDialog", "\347\233\256\346\240\207", Q_NULLPTR));
        target_start->setText(QApplication::translate("IconDialog", "\347\233\256\346\240\207", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class IconDialog: public Ui_IconDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ICONDIALOG_H
