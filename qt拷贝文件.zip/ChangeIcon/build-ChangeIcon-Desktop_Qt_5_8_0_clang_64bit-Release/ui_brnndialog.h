/********************************************************************************
** Form generated from reading UI file 'brnndialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BRNNDIALOG_H
#define UI_BRNNDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include "PathLineEdit.h"

QT_BEGIN_NAMESPACE

class Ui_BRNNDialog
{
public:
    QPushButton *targetBtn;
    QPushButton *startBtn;
    PathLineEdit *dir_product;
    PathLineEdit *bg;
    QPushButton *bg_resource;
    QPushButton *bg_studio;
    QLabel *label_2;
    QLabel *label;
    QLabel *label_3;

    void setupUi(QDialog *BRNNDialog)
    {
        if (BRNNDialog->objectName().isEmpty())
            BRNNDialog->setObjectName(QStringLiteral("BRNNDialog"));
        BRNNDialog->resize(600, 350);
        targetBtn = new QPushButton(BRNNDialog);
        targetBtn->setObjectName(QStringLiteral("targetBtn"));
        targetBtn->setGeometry(QRect(340, 250, 113, 60));
        QFont font;
        font.setPointSize(22);
        targetBtn->setFont(font);
        targetBtn->setCursor(QCursor(Qt::PointingHandCursor));
        targetBtn->setStyleSheet(QStringLiteral("color:rgb(86, 37, 255)"));
        startBtn = new QPushButton(BRNNDialog);
        startBtn->setObjectName(QStringLiteral("startBtn"));
        startBtn->setGeometry(QRect(130, 250, 113, 60));
        startBtn->setFont(font);
        startBtn->setCursor(QCursor(Qt::PointingHandCursor));
        startBtn->setStyleSheet(QStringLiteral("color:rgb(255, 48, 67)"));
        dir_product = new PathLineEdit(BRNNDialog);
        dir_product->setObjectName(QStringLiteral("dir_product"));
        dir_product->setGeometry(QRect(90, 50, 481, 30));
        QFont font1;
        font1.setPointSize(18);
        dir_product->setFont(font1);
        dir_product->setCursor(QCursor(Qt::IBeamCursor));
        dir_product->setFocusPolicy(Qt::StrongFocus);
        dir_product->setDragEnabled(false);
        bg = new PathLineEdit(BRNNDialog);
        bg->setObjectName(QStringLiteral("bg"));
        bg->setGeometry(QRect(90, 110, 481, 30));
        bg->setFont(font1);
        bg->setCursor(QCursor(Qt::IBeamCursor));
        bg->setFocusPolicy(Qt::StrongFocus);
        bg->setDragEnabled(false);
        bg_resource = new QPushButton(BRNNDialog);
        bg_resource->setObjectName(QStringLiteral("bg_resource"));
        bg_resource->setGeometry(QRect(480, 290, 113, 60));
        bg_resource->setFont(font);
        bg_resource->setCursor(QCursor(Qt::PointingHandCursor));
        bg_resource->setStyleSheet(QStringLiteral("color:rgb(86, 37, 255)"));
        bg_studio = new QPushButton(BRNNDialog);
        bg_studio->setObjectName(QStringLiteral("bg_studio"));
        bg_studio->setGeometry(QRect(10, 290, 113, 60));
        bg_studio->setFont(font);
        bg_studio->setCursor(QCursor(Qt::PointingHandCursor));
        bg_studio->setStyleSheet(QStringLiteral("color:rgb(86, 37, 255)"));
        label_2 = new QLabel(BRNNDialog);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(-20, 110, 100, 30));
        label_2->setFont(font1);
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label = new QLabel(BRNNDialog);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(-20, 50, 100, 30));
        label->setFont(font1);
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_3 = new QLabel(BRNNDialog);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(239, 0, 121, 40));
        QFont font2;
        font2.setFamily(QStringLiteral("Kaiti SC"));
        font2.setPointSize(30);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(50);
        label_3->setFont(font2);
        label_3->setStyleSheet(QLatin1String("font: 30pt \"Kaiti SC\";color: rgb(255, 0, 0)\n"
""));
        label_3->setAlignment(Qt::AlignCenter);

        retranslateUi(BRNNDialog);

        QMetaObject::connectSlotsByName(BRNNDialog);
    } // setupUi

    void retranslateUi(QDialog *BRNNDialog)
    {
        BRNNDialog->setWindowTitle(QApplication::translate("BRNNDialog", "Dialog", Q_NULLPTR));
        targetBtn->setText(QApplication::translate("BRNNDialog", "\347\233\256\346\240\207", Q_NULLPTR));
        startBtn->setText(QApplication::translate("BRNNDialog", "\345\274\200\345\247\213", Q_NULLPTR));
        dir_product->setPlaceholderText(QApplication::translate("BRNNDialog", "\345\267\245\347\250\213\347\233\256\345\275\225", Q_NULLPTR));
        bg->setPlaceholderText(QApplication::translate("BRNNDialog", "\350\203\214\346\231\257", Q_NULLPTR));
        bg_resource->setText(QApplication::translate("BRNNDialog", "resource", Q_NULLPTR));
        bg_studio->setText(QApplication::translate("BRNNDialog", "studio", Q_NULLPTR));
        label_2->setText(QApplication::translate("BRNNDialog", "\350\203\214\346\231\257", Q_NULLPTR));
        label->setText(QApplication::translate("BRNNDialog", "\345\267\245\347\250\213\347\233\256\345\275\225", Q_NULLPTR));
        label_3->setText(QApplication::translate("BRNNDialog", "\347\231\276\344\272\272\347\211\233\347\211\233", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class BRNNDialog: public Ui_BRNNDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BRNNDIALOG_H
