/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>
#include "PathLineEdit.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    PathLineEdit *dir_product;
    QPushButton *view_ddz;
    QPushButton *view_config;
    QPushButton *view_logo;
    QPushButton *view_icon;
    QPushButton *view_hall;
    QPushButton *view_tool;
    QPushButton *view_brnn;
    QPushButton *record;
    QPushButton *view_zjh;
    QPushButton *view_bjl;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(600, 400);
        MainWindow->setCursor(QCursor(Qt::ArrowCursor));
        MainWindow->setAcceptDrops(true);
        MainWindow->setInputMethodHints(Qt::ImhNoAutoUppercase|Qt::ImhSensitiveData);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        dir_product = new PathLineEdit(centralWidget);
        dir_product->setObjectName(QStringLiteral("dir_product"));
        dir_product->setGeometry(QRect(60, 40, 431, 30));
        QFont font;
        font.setPointSize(18);
        dir_product->setFont(font);
        dir_product->setCursor(QCursor(Qt::IBeamCursor));
        dir_product->setFocusPolicy(Qt::StrongFocus);
        dir_product->setDragEnabled(false);
        view_ddz = new QPushButton(centralWidget);
        view_ddz->setObjectName(QStringLiteral("view_ddz"));
        view_ddz->setGeometry(QRect(200, 180, 113, 60));
        QFont font1;
        font1.setPointSize(22);
        view_ddz->setFont(font1);
        view_ddz->setCursor(QCursor(Qt::PointingHandCursor));
        view_config = new QPushButton(centralWidget);
        view_config->setObjectName(QStringLiteral("view_config"));
        view_config->setGeometry(QRect(50, 100, 113, 60));
        view_config->setFont(font1);
        view_config->setCursor(QCursor(Qt::PointingHandCursor));
        view_logo = new QPushButton(centralWidget);
        view_logo->setObjectName(QStringLiteral("view_logo"));
        view_logo->setGeometry(QRect(200, 100, 131, 60));
        view_logo->setFont(font1);
        view_logo->setCursor(QCursor(Qt::PointingHandCursor));
        view_icon = new QPushButton(centralWidget);
        view_icon->setObjectName(QStringLiteral("view_icon"));
        view_icon->setGeometry(QRect(350, 100, 151, 60));
        view_icon->setFont(font1);
        view_icon->setCursor(QCursor(Qt::PointingHandCursor));
        view_hall = new QPushButton(centralWidget);
        view_hall->setObjectName(QStringLiteral("view_hall"));
        view_hall->setGeometry(QRect(50, 180, 113, 60));
        view_hall->setFont(font1);
        view_hall->setCursor(QCursor(Qt::PointingHandCursor));
        view_tool = new QPushButton(centralWidget);
        view_tool->setObjectName(QStringLiteral("view_tool"));
        view_tool->setGeometry(QRect(50, 260, 113, 60));
        view_tool->setFont(font1);
        view_tool->setCursor(QCursor(Qt::PointingHandCursor));
        view_brnn = new QPushButton(centralWidget);
        view_brnn->setObjectName(QStringLiteral("view_brnn"));
        view_brnn->setGeometry(QRect(340, 180, 113, 60));
        view_brnn->setFont(font1);
        view_brnn->setCursor(QCursor(Qt::PointingHandCursor));
        record = new QPushButton(centralWidget);
        record->setObjectName(QStringLiteral("record"));
        record->setGeometry(QRect(500, 30, 81, 51));
        record->setFont(font1);
        record->setCursor(QCursor(Qt::PointingHandCursor));
        view_zjh = new QPushButton(centralWidget);
        view_zjh->setObjectName(QStringLiteral("view_zjh"));
        view_zjh->setGeometry(QRect(200, 260, 113, 60));
        view_zjh->setFont(font1);
        view_zjh->setCursor(QCursor(Qt::PointingHandCursor));
        view_bjl = new QPushButton(centralWidget);
        view_bjl->setObjectName(QStringLiteral("view_bjl"));
        view_bjl->setGeometry(QRect(340, 260, 113, 60));
        view_bjl->setFont(font1);
        view_bjl->setCursor(QCursor(Qt::PointingHandCursor));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "\345\267\245\345\205\267", Q_NULLPTR));
        dir_product->setPlaceholderText(QApplication::translate("MainWindow", "\345\267\245\347\250\213\347\233\256\345\275\225", Q_NULLPTR));
        view_ddz->setText(QApplication::translate("MainWindow", "\346\226\227\345\234\260\344\270\273", Q_NULLPTR));
        view_config->setText(QApplication::translate("MainWindow", "\351\205\215\347\275\256", Q_NULLPTR));
        view_logo->setText(QApplication::translate("MainWindow", "logo/\350\203\214\346\231\257", Q_NULLPTR));
        view_icon->setText(QApplication::translate("MainWindow", "icon/\345\220\257\345\212\250\345\233\276", Q_NULLPTR));
        view_hall->setText(QApplication::translate("MainWindow", "\345\244\247\345\216\205", Q_NULLPTR));
        view_tool->setText(QApplication::translate("MainWindow", "\345\212\240\345\257\206\345\267\245\345\205\267", Q_NULLPTR));
        view_brnn->setText(QApplication::translate("MainWindow", "\347\231\276\344\272\272\347\211\233\347\211\233", Q_NULLPTR));
        record->setText(QApplication::translate("MainWindow", "\347\272\252\345\275\225", Q_NULLPTR));
        view_zjh->setText(QApplication::translate("MainWindow", "\347\202\270\351\207\221\350\212\261", Q_NULLPTR));
        view_bjl->setText(QApplication::translate("MainWindow", "\347\231\276\345\256\266\344\271\220", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
