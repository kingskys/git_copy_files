/********************************************************************************
** Form generated from reading UI file 'halldialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HALLDIALOG_H
#define UI_HALLDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include "PathLineEdit.h"

QT_BEGIN_NAMESPACE

class Ui_HallDialog
{
public:
    PathLineEdit *dir_product;
    PathLineEdit *bg;
    PathLineEdit *bottom;
    PathLineEdit *head_bg;
    PathLineEdit *head_icon;
    PathLineEdit *btn_recharge;
    PathLineEdit *icon_gold;
    PathLineEdit *icon_gold_bg;
    PathLineEdit *btn_back;
    PathLineEdit *room_1;
    PathLineEdit *room_2;
    PathLineEdit *room_3;
    PathLineEdit *room_4;
    PathLineEdit *game_ddz;
    PathLineEdit *game_zjh;
    PathLineEdit *game_brnn;
    PathLineEdit *game_bjl;
    QPushButton *startBtn;
    QPushButton *targetBtn;

    void setupUi(QDialog *HallDialog)
    {
        if (HallDialog->objectName().isEmpty())
            HallDialog->setObjectName(QStringLiteral("HallDialog"));
        HallDialog->resize(800, 620);
        dir_product = new PathLineEdit(HallDialog);
        dir_product->setObjectName(QStringLiteral("dir_product"));
        dir_product->setGeometry(QRect(60, 10, 481, 30));
        QFont font;
        font.setPointSize(18);
        dir_product->setFont(font);
        dir_product->setCursor(QCursor(Qt::IBeamCursor));
        dir_product->setFocusPolicy(Qt::StrongFocus);
        dir_product->setDragEnabled(false);
        bg = new PathLineEdit(HallDialog);
        bg->setObjectName(QStringLiteral("bg"));
        bg->setGeometry(QRect(60, 60, 481, 30));
        bg->setFont(font);
        bg->setCursor(QCursor(Qt::IBeamCursor));
        bg->setFocusPolicy(Qt::StrongFocus);
        bg->setDragEnabled(false);
        bottom = new PathLineEdit(HallDialog);
        bottom->setObjectName(QStringLiteral("bottom"));
        bottom->setGeometry(QRect(60, 90, 481, 30));
        bottom->setFont(font);
        bottom->setCursor(QCursor(Qt::IBeamCursor));
        bottom->setFocusPolicy(Qt::StrongFocus);
        bottom->setDragEnabled(false);
        head_bg = new PathLineEdit(HallDialog);
        head_bg->setObjectName(QStringLiteral("head_bg"));
        head_bg->setGeometry(QRect(60, 120, 481, 30));
        head_bg->setFont(font);
        head_bg->setCursor(QCursor(Qt::IBeamCursor));
        head_bg->setFocusPolicy(Qt::StrongFocus);
        head_bg->setDragEnabled(false);
        head_icon = new PathLineEdit(HallDialog);
        head_icon->setObjectName(QStringLiteral("head_icon"));
        head_icon->setGeometry(QRect(60, 150, 481, 30));
        head_icon->setFont(font);
        head_icon->setCursor(QCursor(Qt::IBeamCursor));
        head_icon->setFocusPolicy(Qt::StrongFocus);
        head_icon->setDragEnabled(false);
        btn_recharge = new PathLineEdit(HallDialog);
        btn_recharge->setObjectName(QStringLiteral("btn_recharge"));
        btn_recharge->setGeometry(QRect(60, 260, 481, 30));
        btn_recharge->setFont(font);
        btn_recharge->setCursor(QCursor(Qt::IBeamCursor));
        btn_recharge->setFocusPolicy(Qt::StrongFocus);
        btn_recharge->setDragEnabled(false);
        icon_gold = new PathLineEdit(HallDialog);
        icon_gold->setObjectName(QStringLiteral("icon_gold"));
        icon_gold->setGeometry(QRect(60, 200, 481, 30));
        icon_gold->setFont(font);
        icon_gold->setCursor(QCursor(Qt::IBeamCursor));
        icon_gold->setFocusPolicy(Qt::StrongFocus);
        icon_gold->setDragEnabled(false);
        icon_gold_bg = new PathLineEdit(HallDialog);
        icon_gold_bg->setObjectName(QStringLiteral("icon_gold_bg"));
        icon_gold_bg->setGeometry(QRect(60, 230, 481, 30));
        icon_gold_bg->setFont(font);
        icon_gold_bg->setCursor(QCursor(Qt::IBeamCursor));
        icon_gold_bg->setFocusPolicy(Qt::StrongFocus);
        icon_gold_bg->setDragEnabled(false);
        btn_back = new PathLineEdit(HallDialog);
        btn_back->setObjectName(QStringLiteral("btn_back"));
        btn_back->setGeometry(QRect(60, 290, 481, 30));
        btn_back->setFont(font);
        btn_back->setCursor(QCursor(Qt::IBeamCursor));
        btn_back->setFocusPolicy(Qt::StrongFocus);
        btn_back->setDragEnabled(false);
        room_1 = new PathLineEdit(HallDialog);
        room_1->setObjectName(QStringLiteral("room_1"));
        room_1->setGeometry(QRect(60, 340, 481, 30));
        room_1->setFont(font);
        room_1->setCursor(QCursor(Qt::IBeamCursor));
        room_1->setFocusPolicy(Qt::StrongFocus);
        room_1->setDragEnabled(false);
        room_2 = new PathLineEdit(HallDialog);
        room_2->setObjectName(QStringLiteral("room_2"));
        room_2->setGeometry(QRect(60, 370, 481, 30));
        room_2->setFont(font);
        room_2->setCursor(QCursor(Qt::IBeamCursor));
        room_2->setFocusPolicy(Qt::StrongFocus);
        room_2->setDragEnabled(false);
        room_3 = new PathLineEdit(HallDialog);
        room_3->setObjectName(QStringLiteral("room_3"));
        room_3->setGeometry(QRect(60, 400, 481, 30));
        room_3->setFont(font);
        room_3->setCursor(QCursor(Qt::IBeamCursor));
        room_3->setFocusPolicy(Qt::StrongFocus);
        room_3->setDragEnabled(false);
        room_4 = new PathLineEdit(HallDialog);
        room_4->setObjectName(QStringLiteral("room_4"));
        room_4->setGeometry(QRect(60, 430, 481, 30));
        room_4->setFont(font);
        room_4->setCursor(QCursor(Qt::IBeamCursor));
        room_4->setFocusPolicy(Qt::StrongFocus);
        room_4->setDragEnabled(false);
        game_ddz = new PathLineEdit(HallDialog);
        game_ddz->setObjectName(QStringLiteral("game_ddz"));
        game_ddz->setGeometry(QRect(60, 480, 481, 30));
        game_ddz->setFont(font);
        game_ddz->setCursor(QCursor(Qt::IBeamCursor));
        game_ddz->setFocusPolicy(Qt::StrongFocus);
        game_ddz->setDragEnabled(false);
        game_zjh = new PathLineEdit(HallDialog);
        game_zjh->setObjectName(QStringLiteral("game_zjh"));
        game_zjh->setGeometry(QRect(60, 510, 481, 30));
        game_zjh->setFont(font);
        game_zjh->setCursor(QCursor(Qt::IBeamCursor));
        game_zjh->setFocusPolicy(Qt::StrongFocus);
        game_zjh->setDragEnabled(false);
        game_brnn = new PathLineEdit(HallDialog);
        game_brnn->setObjectName(QStringLiteral("game_brnn"));
        game_brnn->setGeometry(QRect(60, 540, 481, 30));
        game_brnn->setFont(font);
        game_brnn->setCursor(QCursor(Qt::IBeamCursor));
        game_brnn->setFocusPolicy(Qt::StrongFocus);
        game_brnn->setDragEnabled(false);
        game_bjl = new PathLineEdit(HallDialog);
        game_bjl->setObjectName(QStringLiteral("game_bjl"));
        game_bjl->setGeometry(QRect(60, 570, 481, 30));
        game_bjl->setFont(font);
        game_bjl->setCursor(QCursor(Qt::IBeamCursor));
        game_bjl->setFocusPolicy(Qt::StrongFocus);
        game_bjl->setDragEnabled(false);
        startBtn = new QPushButton(HallDialog);
        startBtn->setObjectName(QStringLiteral("startBtn"));
        startBtn->setGeometry(QRect(620, 60, 113, 61));
        QFont font1;
        font1.setFamily(QStringLiteral("STKaiti"));
        font1.setPointSize(30);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        startBtn->setFont(font1);
        startBtn->setCursor(QCursor(Qt::PointingHandCursor));
        startBtn->setStyleSheet(QStringLiteral("font: 30pt \"STKaiti\";color:rgb(255, 0, 0)"));
        targetBtn = new QPushButton(HallDialog);
        targetBtn->setObjectName(QStringLiteral("targetBtn"));
        targetBtn->setGeometry(QRect(620, 180, 113, 61));
        targetBtn->setFont(font1);
        targetBtn->setCursor(QCursor(Qt::PointingHandCursor));
        targetBtn->setStyleSheet(QStringLiteral("font: 30pt \"STKaiti\";color:rgb(97, 121, 255)"));

        retranslateUi(HallDialog);

        QMetaObject::connectSlotsByName(HallDialog);
    } // setupUi

    void retranslateUi(QDialog *HallDialog)
    {
        HallDialog->setWindowTitle(QApplication::translate("HallDialog", "\345\244\247\345\216\205", Q_NULLPTR));
        dir_product->setPlaceholderText(QApplication::translate("HallDialog", "\345\267\245\347\250\213\347\233\256\345\275\225", Q_NULLPTR));
        bg->setPlaceholderText(QApplication::translate("HallDialog", "\350\203\214\346\231\257\345\233\276\347\211\207", Q_NULLPTR));
        bottom->setPlaceholderText(QApplication::translate("HallDialog", "\345\272\225\346\235\241", Q_NULLPTR));
        head_bg->setPlaceholderText(QApplication::translate("HallDialog", "\345\244\264\345\203\217\345\272\225", Q_NULLPTR));
        head_icon->setPlaceholderText(QApplication::translate("HallDialog", "\345\244\264\345\203\217", Q_NULLPTR));
        btn_recharge->setPlaceholderText(QApplication::translate("HallDialog", "\345\205\205\345\200\274\346\214\211\351\222\256", Q_NULLPTR));
        icon_gold->setPlaceholderText(QApplication::translate("HallDialog", "\351\207\221\345\270\201icon", Q_NULLPTR));
        icon_gold_bg->setPlaceholderText(QApplication::translate("HallDialog", "\351\207\221\345\270\201icon\345\272\225", Q_NULLPTR));
        btn_back->setPlaceholderText(QApplication::translate("HallDialog", "\350\277\224\345\233\236\346\214\211\351\222\256", Q_NULLPTR));
        room_1->setPlaceholderText(QApplication::translate("HallDialog", "\346\210\277\351\227\2641", Q_NULLPTR));
        room_2->setPlaceholderText(QApplication::translate("HallDialog", "\346\210\277\351\227\2642", Q_NULLPTR));
        room_3->setPlaceholderText(QApplication::translate("HallDialog", "\346\210\277\351\227\2643", Q_NULLPTR));
        room_4->setPlaceholderText(QApplication::translate("HallDialog", "\346\210\277\351\227\2644", Q_NULLPTR));
        game_ddz->setPlaceholderText(QApplication::translate("HallDialog", "\346\226\227\345\234\260\344\270\273", Q_NULLPTR));
        game_zjh->setPlaceholderText(QApplication::translate("HallDialog", "\347\202\270\351\207\221\350\212\261", Q_NULLPTR));
        game_brnn->setPlaceholderText(QApplication::translate("HallDialog", "\347\231\276\344\272\272\347\211\233\347\211\233", Q_NULLPTR));
        game_bjl->setPlaceholderText(QApplication::translate("HallDialog", "\347\231\276\345\256\266\344\271\220", Q_NULLPTR));
        startBtn->setText(QApplication::translate("HallDialog", "\345\274\200\345\247\213", Q_NULLPTR));
        targetBtn->setText(QApplication::translate("HallDialog", "\347\233\256\346\240\207", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class HallDialog: public Ui_HallDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HALLDIALOG_H
