/********************************************************************************
** Form generated from reading UI file 'logodialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGODIALOG_H
#define UI_LOGODIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include "PathLineEdit.h"

QT_BEGIN_NAMESPACE

class Ui_LogoDialog
{
public:
    PathLineEdit *logo_big_left_light;
    PathLineEdit *logo_big_left_dark;
    PathLineEdit *logo_big;
    PathLineEdit *bg_loading;
    PathLineEdit *logo_hall;
    PathLineEdit *bg_hall;
    PathLineEdit *dir_product;
    QPushButton *startBtn;
    QPushButton *targetBtn;

    void setupUi(QDialog *LogoDialog)
    {
        if (LogoDialog->objectName().isEmpty())
            LogoDialog->setObjectName(QStringLiteral("LogoDialog"));
        LogoDialog->resize(600, 500);
        logo_big_left_light = new PathLineEdit(LogoDialog);
        logo_big_left_light->setObjectName(QStringLiteral("logo_big_left_light"));
        logo_big_left_light->setGeometry(QRect(60, 200, 480, 30));
        QFont font;
        font.setPointSize(18);
        logo_big_left_light->setFont(font);
        logo_big_left_light->setCursor(QCursor(Qt::IBeamCursor));
        logo_big_left_light->setFocusPolicy(Qt::StrongFocus);
        logo_big_left_light->setDragEnabled(false);
        logo_big_left_dark = new PathLineEdit(LogoDialog);
        logo_big_left_dark->setObjectName(QStringLiteral("logo_big_left_dark"));
        logo_big_left_dark->setGeometry(QRect(60, 240, 480, 30));
        logo_big_left_dark->setFont(font);
        logo_big_left_dark->setCursor(QCursor(Qt::IBeamCursor));
        logo_big_left_dark->setFocusPolicy(Qt::StrongFocus);
        logo_big_left_dark->setDragEnabled(false);
        logo_big = new PathLineEdit(LogoDialog);
        logo_big->setObjectName(QStringLiteral("logo_big"));
        logo_big->setGeometry(QRect(60, 160, 480, 30));
        logo_big->setFont(font);
        logo_big->setCursor(QCursor(Qt::IBeamCursor));
        logo_big->setFocusPolicy(Qt::StrongFocus);
        logo_big->setDragEnabled(false);
        bg_loading = new PathLineEdit(LogoDialog);
        bg_loading->setObjectName(QStringLiteral("bg_loading"));
        bg_loading->setGeometry(QRect(60, 290, 480, 30));
        bg_loading->setFont(font);
        bg_loading->setCursor(QCursor(Qt::IBeamCursor));
        bg_loading->setFocusPolicy(Qt::StrongFocus);
        bg_loading->setDragEnabled(false);
        logo_hall = new PathLineEdit(LogoDialog);
        logo_hall->setObjectName(QStringLiteral("logo_hall"));
        logo_hall->setGeometry(QRect(60, 120, 480, 30));
        logo_hall->setFont(font);
        logo_hall->setCursor(QCursor(Qt::IBeamCursor));
        logo_hall->setFocusPolicy(Qt::StrongFocus);
        logo_hall->setDragEnabled(false);
        bg_hall = new PathLineEdit(LogoDialog);
        bg_hall->setObjectName(QStringLiteral("bg_hall"));
        bg_hall->setGeometry(QRect(60, 330, 480, 30));
        bg_hall->setFont(font);
        bg_hall->setCursor(QCursor(Qt::IBeamCursor));
        bg_hall->setFocusPolicy(Qt::StrongFocus);
        bg_hall->setDragEnabled(false);
        dir_product = new PathLineEdit(LogoDialog);
        dir_product->setObjectName(QStringLiteral("dir_product"));
        dir_product->setGeometry(QRect(60, 50, 481, 30));
        dir_product->setFont(font);
        dir_product->setCursor(QCursor(Qt::IBeamCursor));
        dir_product->setFocusPolicy(Qt::StrongFocus);
        dir_product->setDragEnabled(false);
        startBtn = new QPushButton(LogoDialog);
        startBtn->setObjectName(QStringLiteral("startBtn"));
        startBtn->setGeometry(QRect(130, 410, 113, 60));
        QFont font1;
        font1.setPointSize(22);
        startBtn->setFont(font1);
        startBtn->setCursor(QCursor(Qt::PointingHandCursor));
        startBtn->setStyleSheet(QStringLiteral("color:rgb(255, 42, 64)"));
        targetBtn = new QPushButton(LogoDialog);
        targetBtn->setObjectName(QStringLiteral("targetBtn"));
        targetBtn->setGeometry(QRect(350, 410, 113, 60));
        targetBtn->setFont(font1);
        targetBtn->setCursor(QCursor(Qt::PointingHandCursor));
        targetBtn->setStyleSheet(QStringLiteral("color:rgb(96, 53, 255)"));

        retranslateUi(LogoDialog);

        QMetaObject::connectSlotsByName(LogoDialog);
    } // setupUi

    void retranslateUi(QDialog *LogoDialog)
    {
        LogoDialog->setWindowTitle(QApplication::translate("LogoDialog", "logo\345\222\214\350\203\214\346\231\257\345\233\276", Q_NULLPTR));
        logo_big_left_light->setPlaceholderText(QApplication::translate("LogoDialog", "\345\244\247logo\344\272\256\357\274\210\345\267\246\357\274\211\350\267\257\345\276\204", Q_NULLPTR));
        logo_big_left_dark->setPlaceholderText(QApplication::translate("LogoDialog", "\345\244\247logo\347\201\260\357\274\210\345\267\246\357\274\211\350\267\257\345\276\204", Q_NULLPTR));
        logo_big->setPlaceholderText(QApplication::translate("LogoDialog", "\345\244\247logo\344\272\256\357\274\210\346\255\243\357\274\211\350\267\257\345\276\204", Q_NULLPTR));
        bg_loading->setPlaceholderText(QApplication::translate("LogoDialog", "\357\274\210\345\212\240\350\275\275/\344\270\213\350\275\275\357\274\211\347\225\214\351\235\242\350\203\214\346\231\257", Q_NULLPTR));
        logo_hall->setPlaceholderText(QApplication::translate("LogoDialog", "\345\244\247\345\216\205logo\350\267\257\345\276\204", Q_NULLPTR));
        bg_hall->setPlaceholderText(QApplication::translate("LogoDialog", "\345\244\247\345\216\205\347\225\214\351\235\242\350\203\214\346\231\257", Q_NULLPTR));
        dir_product->setPlaceholderText(QApplication::translate("LogoDialog", "\345\267\245\347\250\213\347\233\256\345\275\225", Q_NULLPTR));
        startBtn->setText(QApplication::translate("LogoDialog", "\345\274\200\345\247\213", Q_NULLPTR));
        targetBtn->setText(QApplication::translate("LogoDialog", "\347\233\256\345\275\225", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class LogoDialog: public Ui_LogoDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGODIALOG_H
